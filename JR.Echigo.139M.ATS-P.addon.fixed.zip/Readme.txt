本包仅包含补丁部分，线路本体请到http://wash.839m.net/下载。
下载线路后使用官方转换器转换为BVE5版本。
推荐列车（把下面中任意一行复制到JR越後線 - 139M.txt的Vehicle一行中）
Rock_On\Train\JR\Formation\nii\N17.txt     （115系，下载地址：https://mikangogo.github.io/）
Mc_1323\E129\Nii-A25-6.txt                 （E129系，下载地址：https://mc1323bve.blogspot.com/）
bvews\jre127\Vehicle_1M1T_0.txt            （E127系，下载地址：https://bvews.jpn.org/）